# Hotel Turísticos · Portal de consulta

Proyecto para Sistemas Operativos. Interfaz en español con HTML, CSS y JavaScript, backend Java 17+ y PostgreSQL mediante JDBC. Incluye búsqueda, disponibilidad de habitaciones, paginación de 20 filas, resumen y detección de desconexiones. Sin frameworks ni Maven. El equipo conserva su base existente: la aplicación no crea tablas ni modifica datos.

## 1. Qué contiene

- `public/index.html`: estructura visual.
- `public/estilos.css`: diseño adaptable en verde bosque, marfil y tonos neutros.
- `public/app.js`: búsqueda, navegación, avisos y reintentos.
- `src/HotelServidor.java`: servidor web, autenticación, consultas parametrizadas y API.
- `src/ConexionBD.java`: conexión PostgreSQL, SSL y límites de espera.
- `.env.example`: configuración sin contraseñas reales.
- `iniciar.sh`: compila y ejecuta en Ubuntu.
- `deploy/`: servicio systemd y ejemplo HTTPS con Caddy.
- `PRUEBAS.md`: protocolo para la demostración con el switch y diagnóstico.
- `tests/`: comprobaciones automáticas con un controlador simulado, aislado del arranque normal.

Java y JavaScript son lenguajes diferentes. Java se ejecuta en Ubuntu y se comunica con PostgreSQL. JavaScript se ejecuta en el navegador y se comunica únicamente con Java. No abras index.html con doble clic: abre la URL del servidor.

## 2. Instalación en tu Ubuntu

Descarga y extrae el ZIP. Abre una terminal dentro de la carpeta `hotel-turisticos` (desde Archivos: clic derecho → Abrir en una terminal).

Instala las dependencias desde los repositorios de Ubuntu:

```bash
sudo apt update
sudo apt install openjdk-17-jdk-headless libpostgresql-jdbc-java
java -version
cp .env.example .env
chmod 600 .env
nano .env
```

Completa estas dos contraseñas, manteniendo las comillas simples:

```text
DB_PASSWORD='CONTRASEÑA_PRIVADA_DEL_EQUIPO_BD'
APP_PASSWORD='TU_CLAVE_DEL_PORTAL_DE_AL_MENOS_12_CARACTERES'
```

`APP_USER=equipo` y `APP_PASSWORD` son el acceso al portal. `DB_USER=webapp` y `DB_PASSWORD` son el acceso del backend a PostgreSQL. Son cuentas diferentes; no reutilices la contraseña de la base como contraseña del portal. Si una contraseña contiene una comilla simple, usa la sintaxis de comillas apropiada de Bash; el archivo .env se carga como un archivo de shell de confianza. No ejecutes un .env enviado por alguien sin revisarlo.

Guarda en nano con Ctrl+O, Enter y sal con Ctrl+X. Después:

```bash
bash iniciar.sh
```

Abre **http://localhost:8080** en Firefox. El navegador pedirá usuario y contraseña: utiliza `APP_USER` y `APP_PASSWORD`. Este acceso inicial es el diálogo del navegador. La página continuará sirviéndose aunque PostgreSQL esté apagado. Para detener el servidor, presiona Ctrl+C en la terminal.

La primera prueba exige la contraseña real, conectividad hacia la IP de PostgreSQL y autorización del equipo de base de datos. Sin ellas verás el aviso de indisponibilidad; no se sustituye por información ficticia.

## 3. Autorizar la conexión

Desde la computadora que ejecutará Java, ejecuta:

```bash
ip route get 192.168.3.142
```

Envía al equipo de BD la IP que aparece después de `src`. Esa es la dirección local que normalmente verá PostgreSQL en esta ruta. Si hay VPN o NAT, debe autorizarse la dirección de origen que realmente reciba PostgreSQL. Ellos deben configurar su escucha, regla `hostssl`/SCRAM-SHA-256 en `pg_hba.conf` y firewall; la aplicación no modifica esa configuración.

Parámetros incorporados: host `192.168.3.142`, puerto `5432`, base `hotel_turisticos`, usuario `webapp`, `sslmode=require`. El controlador negocia SCRAM según la configuración del servidor; no se implementa SCRAM a mano.

Para comprobar las credenciales desde la misma máquina:

```bash
sudo apt install postgresql-client
psql "host=192.168.3.142 port=5432 dbname=hotel_turisticos user=webapp sslmode=require connect_timeout=5" -W -c "SELECT 1;"
```

La contraseña se solicita de forma interactiva. No la escribas en la línea de comando. Con el equipo de BD, verifica:

```sql
SELECT table_schema, table_name, column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('habitaciones','huespedes','servicio_adicional',
                    'reservacion','facturacion','servicio_reservacion')
ORDER BY table_name, ordinal_position;
```

**Diferencia con la imagen:** el diagrama muestra una clave compuesta en Servicio_Reservacion y no muestra `id_servicio_reservacion`. El código usa la especificación escrita que sí incluye ese identificador y admite repetir un servicio en la misma reserva. Confirmen que la base real sigue esa especificación. También se asume el esquema `public`, nombres en minúsculas y `fecha_servicioadd` exactamente como se indicó. Si la base utiliza nombres entre comillas y mayúsculas, hay que ajustar las consultas del backend.

## 4. Funcionalidad

Se consultan las seis tablas. Reservaciones, facturas y servicios por reserva incorporan los nombres de huéspedes y los datos relacionados mediante JOIN. La búsqueda es parcial, no distingue mayúsculas, y trata `%`, `_` y comillas como texto literal. No elimina acentos. Se busca dentro de la sección elegida, no en todas a la vez. Se aceptan hasta 100 caracteres; las fechas se buscan en formato `AAAA-MM-DD`.

El resumen es general y no cambia con el buscador. Los resultados se ordenan por identificador descendente y se paginan de 20 en 20. Si otro equipo elimina datos y una página queda vacía, vuelve a la página anterior. Las consultas no ofrecen una instantánea transaccional única entre resumen y listado: pueden variar ligeramente si otro equipo escribe simultáneamente.

Las habitaciones muestran `TRUE = Disponible` y `FALSE = No disponible`. Para reservaciones se muestra `TRUE/FALSE`: el equipo no definió aún su significado y no se ha supuesto que sean “confirmada” o “cancelada”. Los importes se presentan en quetzales como elección de interfaz por el contexto de Guatemala; confirmen esa moneda con el equipo. No se calcula precio por noche ni total por estancia porque esas columnas no existen en la estructura recibida. El costo de servicio por reserva es el costo actual de catálogo, no un precio histórico garantizado.

Aunque `webapp` tenga permisos de escritura, esta primera entrega es de **consulta**, conforme al buscador solicitado. No incluye altas, modificaciones, eliminaciones ni cobros.

## 5. Cómo funciona la detección de fallos

Cada carga y búsqueda consulta PostgreSQL. Tras terminar una solicitud, el navegador espera 5 segundos y actualiza de nuevo. Java crea una nueva conexión en cada operación; así puede recuperarse después de un corte. Se cierran conexiones, consultas y resultados con try-with-resources.

- Conexión: `connectTimeout=3` segundos; inicio de sesión: 5 segundos.
- Lectura del socket: 5 segundos; consulta SQL: 4 segundos.
- Navegador: cancela la espera a los 15 segundos.
- Reintento: 5 segundos después de terminar o fallar la solicitud.

No se promete detección instantánea. En una prueba normal el aviso debe aparecer en unos segundos; si la red descarta paquetes, el límite de espera del navegador más el intervalo de actualización puede acercarlo a 20 segundos. Una pestaña en segundo plano puede retrasar los temporizadores del navegador.

Un fallo de conexión devuelve HTTP 503 con un mensaje público. Los errores de esquema, permisos o autenticación se distinguen como problemas de configuración. La interfaz elimina resultados y cifras previas cuando falla una consulta y los vuelve a cargar al recuperarse. No asegura saber si alguien apagó el switch: solo observa que la comunicación falló.

`GET /api/estado` ejecuta `SELECT 1`. `GET /api/datos?seccion=habitaciones&q=&pagina=1&estado=todos` devuelve datos y resumen. Ambas rutas requieren autenticación. El estado no se basa únicamente en que Java esté encendido.

## 6. Mostrarlo en la red local

Para que otros equipos accedan directamente durante una práctica aislada, cambia `BIND_ADDRESS=0.0.0.0` en `.env` y reinicia Java. Abre desde otro equipo `http://IP_DEL_SERVIDOR_WEB:8080`. Si el firewall está activo, autoriza el puerto solo para la IP o subred de la práctica; no desactives el firewall entero.

**HTTP no cifra el acceso al portal.** Usa solamente datos y contraseñas de prueba en una red de laboratorio aislada. Para datos reales y publicación utiliza HTTPS como en la siguiente sección. `DB_SSLMODE=require` cifra el tramo Java → PostgreSQL; no cifra el tramo navegador → Java.

La autenticación básica es una barrera sencilla para la entrega académica, con una cuenta compartida. El navegador recuerda la credencial; usa una ventana privada y ciérrala al finalizar en un equipo compartido. Para un hotel en producción se necesitarían cuentas individuales, roles, auditoría y una gestión completa de sesiones.

## 7. Publicarlo con HTTPS

Se necesita un servidor Ubuntu que ejecute Java, dominio propio y conectividad privada hacia PostgreSQL. Un alojamiento solo de HTML/PHP no basta. La dirección `192.168.3.142` no es accesible desde Internet. En un VPS, primero establece una VPN entre ese servidor y la red de la base (con la ayuda del equipo de redes), actualiza DB_HOST si corresponde y prueba con psql. No abras el puerto 5432 a todo Internet. Si la VPN no existe, la publicación de los archivos por sí sola no hará funcionar la conexión.

En el servidor Ubuntu, instala Java y el controlador como arriba. Copia el proyecto completo a `/opt/hotel-turisticos`. Por ejemplo, después de subir/extractar la carpeta en tu usuario del servidor:

```bash
sudo mkdir -p /opt/hotel-turisticos
sudo cp -a hotel-turisticos/. /opt/hotel-turisticos/
sudo useradd --system --user-group --home-dir /opt/hotel-turisticos --shell /usr/sbin/nologin hotel
cd /opt/hotel-turisticos
sudo cp .env.example .env
sudo nano .env
```

Completa credenciales, conserva `BIND_ADDRESS=127.0.0.1` y `PORT=8080`. Luego:

```bash
sudo mkdir -p build
sudo java -m jdk.compiler/com.sun.tools.javac.Main --release 17 -encoding UTF-8 -d build src/*.java
sudo chown root:hotel .env
sudo chmod 640 .env
sudo cp deploy/hotel.service /etc/systemd/system/hotel.service
sudo systemctl daemon-reload
sudo systemctl enable --now hotel
sudo systemctl status hotel
```

Si ya existe el usuario de sistema `hotel`, omite useradd. El usuario del servicio debe poder leer el proyecto y atravesar sus directorios. No necesita permisos de escritura. Los comandos de publicación no requieren copiar contraseñas al frontend.

Instala Caddy siguiendo su documentación oficial para Debian/Ubuntu: https://caddyserver.com/docs/install . Configura un registro DNS A para el dominio apuntando a la IP pública del servidor. Copia y adapta `deploy/Caddyfile`:

```bash
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo nano /etc/caddy/Caddyfile
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

Abre los puertos TCP 80 y 443 en el firewall del servidor y del proveedor, conservando el acceso administrativo SSH existente. No es necesario abrir 8080 al público. Con un dominio válido y los puertos accesibles, Caddy obtiene el certificado y redirige HTTP a HTTPS. Entra en `https://TU_DOMINIO`. El proxy conserva el encabezado de autenticación del portal.

Para actualizar: copia el código, compila de nuevo y ejecuta `sudo systemctl restart hotel`. Para revisar errores: `sudo journalctl -u hotel -n 50 --no-pager`. Los logs de la aplicación muestran códigos SQL sin datos de huéspedes ni contraseñas.

`sslmode=require` reproduce el requisito del equipo, pero no verifica la identidad del certificado de PostgreSQL. Para un despliegue real, coordinen un certificado válido y `DB_SSLMODE=verify-full`, un DB_HOST que coincida con ese certificado y `DB_SSLROOTCERT` con la ruta de la CA. El acceso desde fuera y el despliegue definitivo no pueden comprobarse hasta contar con servidor, dominio, VPN y credenciales.

## 8. Comprobaciones incluidas y límites

Consulta `PRUEBAS.md`. Las pruebas automáticas usan un controlador JDBC simulado para comprobar el flujo HTTP, la parametrización, la autenticación y el cambio disponible → desconectado → disponible. **No equivalen a probar la base PostgreSQL de tu equipo, su SSL, sus reglas de firewall ni su esquema real.** La base real no está accesible desde el entorno de preparación y no se recibieron sus credenciales. También se validó la sintaxis JavaScript y la compilación de los fuentes Java. No se realizó verificación visual en navegador.

## Referencias técnicas

- pgJDBC, conexión y timeouts: https://jdbc.postgresql.org/documentation/use/
- pgJDBC, SSL: https://jdbc.postgresql.org/documentation/ssl/
- Caddy, HTTPS automático: https://caddyserver.com/docs/automatic-https
- Caddy, reverse_proxy: https://caddyserver.com/docs/caddyfile/directives/reverse_proxy

Las versiones de Ubuntu/PostgreSQL recibidas se toman como información del equipo, no como versiones verificadas en su servidor.
