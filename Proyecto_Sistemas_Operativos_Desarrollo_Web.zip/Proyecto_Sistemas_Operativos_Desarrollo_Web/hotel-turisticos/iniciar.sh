#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ -f .env ]]; then
  set -a
  source .env
  set +a
fi
JDBC_JAR="${JDBC_JAR:-/usr/share/java/postgresql.jar}"
if [[ ! -r "$JDBC_JAR" ]]; then
  echo 'Falta el controlador PostgreSQL. Instala: sudo apt install libpostgresql-jdbc-java' >&2
  exit 1
fi
mkdir -p build
java -m jdk.compiler/com.sun.tools.javac.Main --release 17 -encoding UTF-8 -d build src/*.java
exec java -cp "build:$JDBC_JAR" HotelServidor
