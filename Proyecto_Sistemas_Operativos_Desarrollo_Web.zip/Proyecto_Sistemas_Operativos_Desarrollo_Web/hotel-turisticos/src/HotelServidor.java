import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/** Servidor de consulta para un proyecto académico. No modifica el esquema ni los registros. */
public class HotelServidor {
    record Consulta(String sql, String buscar, String orden) {}
    static final Map<String,Consulta> CONSULTAS = Map.of(
        "habitaciones", new Consulta("SELECT id_habitaciones AS id, numero_cuarto AS numero, tipo_cuarto AS tipo, estado FROM public.habitaciones", "numero_cuarto::text, tipo_cuarto, CASE WHEN estado THEN 'disponible' ELSE 'no disponible' END", "id_habitaciones"),
        "huespedes", new Consulta("SELECT id_huesped AS id, nombre_completo AS nombre, dpi_nit AS documento, direccion, telefono FROM public.huespedes", "nombre_completo, dpi_nit, direccion, telefono", "id_huesped"),
        "reservacion", new Consulta("SELECT r.id_reservacion AS id, h.nombre_completo AS huesped, c.numero_cuarto AS habitacion, r.fecha_inicio AS inicio, r.fecha_fin AS fin, r.estado FROM public.reservacion r JOIN public.huespedes h ON h.id_huesped=r.id_huesped JOIN public.habitaciones c ON c.id_habitaciones=r.id_habitaciones", "r.id_reservacion::text, h.nombre_completo, c.numero_cuarto::text, r.fecha_inicio::text, r.fecha_fin::text", "r.id_reservacion"),
        "servicio_adicional", new Consulta("SELECT id_servicio_adicional AS id, tipo, costo_adicional AS costo, fecha_solicitada AS fecha FROM public.servicio_adicional", "tipo, id_servicio_adicional::text, fecha_solicitada::text", "id_servicio_adicional"),
        "facturacion", new Consulta("SELECT f.id_facturacion AS id, h.nombre_completo AS huesped, f.fecha_factura AS fecha, f.monto_total AS monto, f.metodo_pago AS metodo FROM public.facturacion f JOIN public.huespedes h ON h.id_huesped=f.id_huesped", "f.id_facturacion::text, h.nombre_completo, f.metodo_pago, f.fecha_factura::text", "f.id_facturacion"),
        "servicio_reservacion", new Consulta("SELECT sr.id_servicio_reservacion AS id, sr.id_reservacion AS reservacion, h.nombre_completo AS huesped, s.tipo AS servicio, s.costo_adicional AS costo, sr.fecha_servicioadd AS fecha FROM public.servicio_reservacion sr JOIN public.servicio_adicional s ON s.id_servicio_adicional=sr.id_servicio_adicional JOIN public.reservacion r ON r.id_reservacion=sr.id_reservacion JOIN public.huespedes h ON h.id_huesped=r.id_huesped", "sr.id_reservacion::text, h.nombre_completo, s.tipo, sr.fecha_servicioadd::text", "sr.id_servicio_reservacion")
    );
    static final String RESUMEN = "SELECT (SELECT count(*) FROM public.habitaciones) AS habitaciones, (SELECT count(*) FROM public.habitaciones WHERE estado=true) AS disponibles, (SELECT count(*) FROM public.huespedes) AS huespedes, (SELECT count(*) FROM public.reservacion) AS reservaciones";
    static final Map<String,String> ARCHIVOS = Map.of("/", "index.html", "/index.html", "index.html", "/estilos.css", "estilos.css", "/app.js", "app.js");
    static final Semaphore PLAZAS_DB = new Semaphore(8);

    public static void main(String[] args) throws Exception {
        String usuario = ConexionBD.env("APP_USER", "equipo");
        String clave = ConexionBD.env("APP_PASSWORD", "");
        if (clave.length() < 12 || clave.equals("CAMBIAR_ESTA_CLAVE")) {
            System.err.println("Define APP_PASSWORD con al menos 12 caracteres antes de iniciar.");
            System.exit(1);
        }
        HttpServer servidor = HttpServer.create(new InetSocketAddress(ConexionBD.env("BIND_ADDRESS", "127.0.0.1"), Integer.parseInt(ConexionBD.env("PORT", "8080"))), 32);
        HttpContext contexto = servidor.createContext("/", HotelServidor::atender);
        contexto.setAuthenticator(new BasicAuthenticator("Hotel Turisticos", StandardCharsets.UTF_8) {
            public boolean checkCredentials(String u, String p) {
                return seguro(u, usuario) & seguro(p, clave);
            }
        });
        ThreadPoolExecutor pool = new ThreadPoolExecutor(12,12,0,TimeUnit.SECONDS,new ArrayBlockingQueue<>(48),new ThreadPoolExecutor.CallerRunsPolicy());
        servidor.setExecutor(pool);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> { servidor.stop(1); pool.shutdownNow(); }));
        servidor.start();
        System.out.println("Hotel Turisticos iniciado en puerto " + servidor.getAddress().getPort());
    }
    static boolean seguro(String a, String b) {
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }
    static void atender(HttpExchange e) throws IOException {
        try {
            e.getResponseHeaders().set("Cache-Control", "no-store");
            e.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
            e.getResponseHeaders().set("Referrer-Policy", "no-referrer");
            e.getResponseHeaders().set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
            if (!e.getRequestMethod().equals("GET")) {
                e.getResponseHeaders().set("Allow", "GET"); error(e,405,"METODO","Método no permitido."); return;
            }
            String ruta=e.getRequestURI().getPath();
            if (ruta.equals("/api/datos") || ruta.equals("/api/estado")) {
                if (!PLAZAS_DB.tryAcquire()) { error(e,503,"OCUPADO","El servicio está ocupado. Intenta nuevamente."); return; }
                try { api(e, ruta); } finally { PLAZAS_DB.release(); }
            } else if (ARCHIVOS.containsKey(ruta)) {
                String archivo=ARCHIVOS.get(ruta);
                String tipo=archivo.endsWith(".css") ? "text/css" : archivo.endsWith(".js") ? "text/javascript" : "text/html";
                byte[] bytes=Files.readAllBytes(Path.of("public",archivo));
                enviar(e,200,tipo+"; charset=utf-8",bytes);
            } else error(e,404,"NO_ENCONTRADO","Recurso no encontrado.");
        } catch (IllegalArgumentException ex) {
            error(e,400,"SOLICITUD_INVALIDA","Revisa los parámetros de búsqueda.");
        } catch (SQLException ex) {
            String estado=Objects.toString(ex.getSQLState(), "");
            // No imprimir contraseñas, consultas, datos personales ni mensajes internos del controlador.
            System.err.println(Instant.now()+" Error SQL, código="+estado);
            boolean configuracion=estado.startsWith("42") || estado.startsWith("28") || estado.startsWith("3D");
            error(e, configuracion ? 500 : 503, configuracion ? "CONFIGURACION" : "BASE_NO_DISPONIBLE", configuracion ? "No se pudo consultar la información. El equipo debe revisar la configuración del servicio." : "No podemos comunicarnos con la base de datos en este momento. Por favor, intenta nuevamente en unos instantes.");
        } catch (Exception ex) {
            System.err.println(Instant.now()+" Error del servicio: "+ex.getClass().getSimpleName());
            error(e,500,"ERROR_INTERNO","El servicio está teniendo un inconveniente. Intenta nuevamente.");
        } finally { e.close(); }
    }
    static void api(HttpExchange e, String ruta) throws SQLException, IOException {
        Map<String,String> parametros=parametros(e.getRequestURI().getRawQuery());
        String seccion=parametros.getOrDefault("seccion","habitaciones");
        Consulta consulta=CONSULTAS.get(seccion);
        if (consulta==null) throw new IllegalArgumentException();
        String buscar=parametros.getOrDefault("q","").trim();
        if (buscar.length()>100) throw new IllegalArgumentException();
        int pagina=Integer.parseInt(parametros.getOrDefault("pagina","1"));
        if (pagina<1 || pagina>100000) throw new IllegalArgumentException();
        String estado=parametros.getOrDefault("estado","todos");
        if (!Set.of("todos","disponible","ocupada").contains(estado)) throw new IllegalArgumentException();
        try (Connection c=ConexionBD.abrir()) {
            if (ruta.equals("/api/estado")) {
                try (PreparedStatement p=c.prepareStatement("SELECT 1")) { p.setQueryTimeout(4); try(ResultSet rs=p.executeQuery()){ rs.next(); } }
                json(e,200,Map.of("estado","conectado","comprobado",Instant.now().toString())); return;
            }
            List<Map<String,Object>> resumen;
            try(PreparedStatement p=c.prepareStatement(RESUMEN)) { p.setQueryTimeout(4); try(ResultSet rs=p.executeQuery()){ resumen=filas(rs); } }
            // Los identificadores proceden de una lista fija. Los valores del usuario son parámetros.
            String filtro=" WHERE strpos(lower(concat_ws(' ', "+consulta.buscar()+")), lower(?)) > 0";
            if(seccion.equals("habitaciones") && !estado.equals("todos")) filtro+=" AND estado = ?";
            String sql=consulta.sql()+filtro+" ORDER BY "+consulta.orden()+" DESC LIMIT ? OFFSET ?";
            List<Map<String,Object>> datos;
            try (PreparedStatement p=c.prepareStatement(sql)) {
                p.setQueryTimeout(4); int i=1; p.setString(i++,buscar);
                if(seccion.equals("habitaciones") && !estado.equals("todos")) p.setBoolean(i++,estado.equals("disponible"));
                p.setInt(i++,21); p.setInt(i,(pagina-1)*20);
                try(ResultSet rs=p.executeQuery()){ datos=filas(rs); }
            }
            boolean siguiente=datos.size()>20;
            if(siguiente) datos.remove(datos.size()-1);
            json(e,200,Map.of("datos",datos,"resumen",resumen.get(0),"siguiente",siguiente,"pagina",pagina,"comprobado",Instant.now().toString()));
        }
    }
    static Map<String,String> parametros(String query) {
        Map<String,String> result=new HashMap<>();
        if(query!=null) for(String parte:query.split("&")) { String[] kv=parte.split("=",2); result.put(URLDecoder.decode(kv[0],StandardCharsets.UTF_8),kv.length==2 ? URLDecoder.decode(kv[1],StandardCharsets.UTF_8) : ""); }
        return result;
    }
    static List<Map<String,Object>> filas(ResultSet rs) throws SQLException {
        List<Map<String,Object>> lista=new ArrayList<>(); ResultSetMetaData meta=rs.getMetaData();
        while(rs.next()) { Map<String,Object> fila=new LinkedHashMap<>(); for(int i=1;i<=meta.getColumnCount();i++) fila.put(meta.getColumnLabel(i),rs.getObject(i)); lista.add(fila); }
        return lista;
    }
    static void error(HttpExchange e,int status,String codigo,String mensaje) throws IOException { json(e,status,Map.of("codigo",codigo,"mensaje",mensaje)); }
    static void json(HttpExchange e,int status,Object obj) throws IOException { enviar(e,status,"application/json; charset=utf-8",serializar(obj).getBytes(StandardCharsets.UTF_8)); }
    static void enviar(HttpExchange e,int status,String tipo,byte[] bytes) throws IOException { e.getResponseHeaders().set("Content-Type",tipo); e.sendResponseHeaders(status,bytes.length); e.getResponseBody().write(bytes); }
    static String serializar(Object v) {
        if(v==null) return "null";
        if(v instanceof Number || v instanceof Boolean) return v.toString();
        if(v instanceof Map<?,?> m) { StringJoiner j=new StringJoiner(",","{","}"); m.forEach((k,x)->j.add(serializar(k.toString())+":"+serializar(x))); return j.toString(); }
        if(v instanceof Iterable<?> l) { StringJoiner j=new StringJoiner(",","[","]"); for(Object x:l) j.add(serializar(x)); return j.toString(); }
        StringBuilder b=new StringBuilder("\"");
        for(char ch:v.toString().toCharArray()) { switch(ch) { case '"' -> b.append("\\\""); case '\\' -> b.append("\\\\"); case '\n' -> b.append("\\n"); case '\r' -> b.append("\\r"); case '\t' -> b.append("\\t"); default -> { if(ch<32) b.append(String.format("\\u%04x",(int)ch)); else b.append(ch); } } }
        return b.append('"').toString();
    }
}
