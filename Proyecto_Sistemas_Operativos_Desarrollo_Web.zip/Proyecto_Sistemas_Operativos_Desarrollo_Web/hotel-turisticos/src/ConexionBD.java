import java.sql.*;
import java.util.Properties;

/** Credenciales exclusivamente en el servidor. Una conexión nueva permite recuperarse tras un corte. */
public final class ConexionBD {
    static String env(String nombre, String defecto) {
        String valor = System.getenv(nombre);
        return valor == null || valor.isBlank() ? defecto : valor;
    }
    public static Connection abrir() throws SQLException {
        String password = env("DB_PASSWORD", "");
        if (password.isBlank()) throw new SQLException("Falta configuración", "08001");
        Properties p = new Properties();
        p.setProperty("user", env("DB_USER", "webapp"));
        p.setProperty("password", password);
        p.setProperty("sslmode", env("DB_SSLMODE", "require"));
        p.setProperty("connectTimeout", "3");
        p.setProperty("loginTimeout", "5");
        p.setProperty("socketTimeout", "5");
        p.setProperty("cancelSignalTimeout", "1");
        p.setProperty("ApplicationName", "HotelTuristicosWeb");
        p.setProperty("options", "-c statement_timeout=4000 -c default_transaction_read_only=on");
        if (!env("DB_SSLROOTCERT", "").isBlank()) p.setProperty("sslrootcert", env("DB_SSLROOTCERT", ""));
        String host = env("DB_HOST", "192.168.3.142");
        String port = env("DB_PORT", "5432");
        String database = env("DB_NAME", "hotel_turisticos");
        if (!host.matches("[a-zA-Z0-9.-]+") || !port.matches("[0-9]{1,5}") || !database.matches("[a-zA-Z0-9_]+"))
            throw new SQLException("Configuración inválida", "08001");
        return DriverManager.getConnection("jdbc:postgresql://"+host+":"+port+"/"+database, p);
    }
}
