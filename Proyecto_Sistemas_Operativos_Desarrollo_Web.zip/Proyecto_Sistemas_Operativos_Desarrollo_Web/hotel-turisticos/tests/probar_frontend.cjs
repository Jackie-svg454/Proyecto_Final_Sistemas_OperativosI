// Prueba de estado del JS con un DOM mínimo, no sustituye una prueba visual en navegador.
const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
class Element {
 constructor(){this.hidden=false;this.value='';this.children=[];this.textContent='';this.disabled=false;this.className='';this.listeners={};this.dataset={};this.classList={toggle(){}};}
 append(child){this.children.push(child);}replaceChildren(...children){this.children=children;}
 addEventListener(event,fn){this.listeners[event]=fn;}setAttribute(){}removeAttribute(){}
}
const ids=new Map();const get=id=>{if(!ids.has(id))ids.set(id,new Element());return ids.get(id);};get('filtro').value='todos';
let next=0;const timers=new Map();
const good={datos:[{id:1,numero:101,tipo:'<script>alert(1)</script>',estado:true}],resumen:{habitaciones:1,disponibles:1,huespedes:1,reservaciones:1},siguiente:false,comprobado:new Date().toISOString()};
const queue=[{ok:true,json:async()=>good}];
const context=vm.createContext({document:{getElementById:get,createElement:()=>new Element(),querySelectorAll:()=>[]},window:{addEventListener(){}},URLSearchParams,AbortController,Intl,Date,console,setTimeout:(fn,delay)=>{timers.set(++next,{fn,delay});return next;},clearTimeout:id=>timers.delete(id),fetch:async()=>{const result=queue.shift();if(result instanceof Error)throw result;return result;}});
vm.runInContext(fs.readFileSync(require('node:path').join(__dirname,'../public/app.js'),'utf8'),context);
(async()=>{
 await new Promise(setImmediate);
 assert.equal(get('conexion').textContent,'Base de datos conectada');
 assert.equal(get('filas').children[0].children[2].textContent,'<script>alert(1)</script>');
 assert.equal(get('aviso').hidden,true);
 queue.push({ok:false,json:async()=>({codigo:'BASE_NO_DISPONIBLE',mensaje:'Sin base'})});
 const poll=[...timers.values()].find(t=>t.delay===5000);assert.ok(poll);await poll.fn();
 assert.equal(get('aviso').hidden,false);assert.equal(get('filas').children.length,0);assert.equal(get('m-habitaciones').textContent,'—');assert.equal(get('siguiente').disabled,true);
 queue.push({ok:true,json:async()=>good});await vm.runInContext('cargar()',context);
 assert.equal(get('aviso').hidden,true);assert.equal(get('tabla-contenedor').hidden,false);
 queue.push(new Error('network'));await vm.runInContext('cargar()',context);assert.match(get('aviso-texto').textContent,/servidor web/);
 queue.push({ok:true,json:async()=>({...good,datos:[]})});await vm.runInContext('cargar()',context);assert.equal(get('vacio').hidden,false);assert.equal(get('aviso').hidden,true);
 console.log('OK: texto seguro, datos visibles, polling, fallo, limpieza, recuperación, red y resultados vacíos.');
})().catch(e=>{console.error(e);process.exitCode=1;});
