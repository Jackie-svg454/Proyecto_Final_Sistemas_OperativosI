"""Prueba HTTP del backend real con un doble JDBC, sin contactar ninguna base externa."""
import base64, json, os, pathlib, socket, subprocess, tempfile, time
import urllib.request, urllib.error, urllib.parse
root=pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as temp:
    temp=pathlib.Path(temp)
    state=temp/'state';state.write_text('up')
    subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','17','-encoding','UTF-8','-d',str(temp),*[str(p) for p in (root/'src').glob('*.java')],str(root/'tests/ControladorSimulado.java')],check=True)
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    env=dict(os.environ,APP_USER='prueba',APP_PASSWORD='prueba-local-123456',DB_PASSWORD='solo-prueba',DB_SSLMODE='require',PORT=str(port),BIND_ADDRESS='127.0.0.1',TEST_STATE=str(state))
    with (temp/'log').open('w') as log:
        process=subprocess.Popen(['java','-Djdbc.drivers=ControladorSimulado','-cp',str(temp),'HotelServidor'],cwd=root,env=env,stdout=log,stderr=log)
        def request(path,auth=True,method='GET'):
            headers={}
            if auth:headers['Authorization']='Basic '+base64.b64encode(b'prueba:prueba-local-123456').decode()
            req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,headers=headers,method=method)
            try:
                with urllib.request.urlopen(req,timeout=5) as r:return r.status,r.read(),r.headers
            except urllib.error.HTTPError as e:return e.code,e.read(),e.headers
        try:
            for _ in range(60):
                try:
                    if request('/')[0]==200:break
                except OSError:pass
                time.sleep(.1)
            else:raise AssertionError('No inició el servidor')
            assert request('/',False)[0]==401
            assert request('/api/datos',False)[0]==401
            assert request('/.env')[0]==404
            assert request('/src/ConexionBD.java')[0]==404
            assert request('/api/datos',method='POST')[0]==405
            for bad in ['?seccion=mal','?pagina=0','?pagina=abc','?estado=mal','?q='+'x'*101]:assert request('/api/datos'+bad)[0]==400
            code,body,headers=request('/api/datos');data=json.loads(body)
            assert code==200 and len(data['datos'])==20 and data['siguiente']
            assert data['resumen']['habitaciones']==25 and '<script>' in data['datos'][0]['tipo']
            assert headers['Cache-Control']=='no-store'
            assert 'frame-ancestors' in headers['Content-Security-Policy']
            data=json.loads(request('/api/datos?pagina=2')[1]);assert len(data['datos'])==5 and not data['siguiente']
            data=json.loads(request('/api/datos?estado=ocupada')[1]);assert all(r['estado'] is False for r in data['datos'])
            for section in ['huespedes','reservacion','servicio_adicional','facturacion','servicio_reservacion']:
                assert request('/api/datos?seccion='+section)[0]==200
            query=urllib.parse.urlencode({'q':"' OR 1=1 --"})
            assert json.loads(request('/api/datos?'+query)[1])['datos']==[]
            state.write_text('down')
            for path in ['/api/datos','/api/estado']:
                code,body,_=request(path);assert code==503 and json.loads(body)['codigo']=='BASE_NO_DISPONIBLE' and b'Secreto' not in body
            assert request('/')[0]==200
            state.write_text('schema');assert request('/api/datos')[0]==500
            state.write_text('up');assert request('/api/estado')[0]==200 and request('/api/datos')[0]==200
            print('OK: compilación, acceso, seis rutas, validación, paginación, parámetros, JSON, fallo 503, esquema 500 y recuperación.')
        finally:
            process.terminate();process.wait(timeout=5)
