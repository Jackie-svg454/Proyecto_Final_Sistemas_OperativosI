import java.lang.reflect.*;
import java.sql.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;

/** Doble de prueba: nunca se incluye en el classpath de la aplicación normal. */
public class ControladorSimulado implements Driver {
 static { try { DriverManager.registerDriver(new ControladorSimulado()); } catch(SQLException e){throw new RuntimeException(e);} }
 static Object defecto(Class<?> t) { if(t==boolean.class)return false;if(t==int.class)return 0;if(t==long.class)return 0L;return null; }
 static <T> T proxy(Class<T> t, InvocationHandler h) {return t.cast(Proxy.newProxyInstance(t.getClassLoader(),new Class<?>[]{t},h));}
 public Connection connect(String url,Properties props) throws SQLException {
  if(!acceptsURL(url))return null;
  if(!"require".equals(props.getProperty("sslmode")))throw new SQLException("SSL incorrecto","08001");
  try {String modo=Files.readString(Path.of(System.getenv("TEST_STATE"))).trim();if(modo.equals("down"))throw new SQLException("Secreto interno","08006");if(modo.equals("schema"))throw new SQLException("Secreto de esquema","42703");}catch(java.io.IOException e){throw new SQLException("Estado de prueba","08001");}
  return proxy(Connection.class,(p,m,a)->m.getName().equals("prepareStatement")?sentencia((String)a[0]):defecto(m.getReturnType()));
 }
 static PreparedStatement sentencia(String sql) {
  Map<Integer,Object> params=new HashMap<>();
  return proxy(PreparedStatement.class,(p,m,a)->{
   if(Set.of("setString","setInt","setBoolean").contains(m.getName())){params.put((Integer)a[0],a[1]);return null;}
   if(m.getName().equals("executeQuery")) {
    if(sql.equals("SELECT 1")) return resultado(List.of(Map.of("uno",1)));
    if(sql.startsWith("SELECT (SELECT count"))return resultado(List.of(Map.of("habitaciones",25,"disponibles",12,"huespedes",5,"reservaciones",7)));
    if(sql.contains("OR 1=1") || !sql.contains("lower(?)"))throw new AssertionError("Consulta sin parametrizar");
    if(!Objects.equals(params.get(1),""))return resultado(List.of());
    List<Map<String,Object>> rows=new ArrayList<>();
    if(sql.contains("FROM public.habitaciones")){
      int offset=(Integer)params.get(params.size());
      for(int i=offset;i<Math.min(offset+21,25);i++){Map<String,Object> row=new LinkedHashMap<>();row.put("id",25-i);row.put("numero",125-i);row.put("tipo","Suite <script> & \"especial\"\n");row.put("estado",params.containsKey(4)?params.get(2):i%2==0);rows.add(row);}
    }
    return resultado(rows);
   }
   return defecto(m.getReturnType());
  });
 }
 static ResultSet resultado(List<Map<String,Object>> rows) {
  List<String> keys=rows.isEmpty()?List.of():new ArrayList<>(rows.get(0).keySet());int[] index={-1};
  ResultSetMetaData meta=proxy(ResultSetMetaData.class,(p,m,a)->switch(m.getName()){case "getColumnCount"->keys.size();case "getColumnLabel"->keys.get((Integer)a[0]-1);default->defecto(m.getReturnType());});
  return proxy(ResultSet.class,(p,m,a)->switch(m.getName()){case "next"->++index[0]<rows.size();case "getMetaData"->meta;case "getObject"->rows.get(index[0]).get(keys.get((Integer)a[0]-1));default->defecto(m.getReturnType());});
 }
 public boolean acceptsURL(String u){return u.startsWith("jdbc:postgresql:");}
 public DriverPropertyInfo[] getPropertyInfo(String u,Properties p){return new DriverPropertyInfo[0];}
 public int getMajorVersion(){return 1;}public int getMinorVersion(){return 0;}public boolean jdbcCompliant(){return false;}public Logger getParentLogger(){return Logger.getGlobal();}
}
