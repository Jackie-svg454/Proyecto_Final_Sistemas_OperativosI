'use strict';
// Nunca contiene credenciales de PostgreSQL. Todas las solicitudes se envían al backend del mismo origen.
const $ = id => document.getElementById(id);
const secciones = {
 habitaciones: { titulo:'Habitaciones', descripcion:'Consulta los espacios y su disponibilidad.', pista:'Buscar por número o tipo de habitación…', columnas:[['id','ID'],['numero','Habitación'],['tipo','Tipo de habitación'],['estado','Disponibilidad']] },
 huespedes: { titulo:'Huéspedes', descripcion:'El directorio de quienes nos visitan.', pista:'Buscar por nombre, DPI/NIT, dirección o teléfono…', columnas:[['id','ID'],['nombre','Nombre completo'],['documento','DPI / NIT'],['direccion','Dirección'],['telefono','Teléfono']] },
 reservacion: { titulo:'Reservaciones', descripcion:'Fechas, huéspedes y habitaciones vinculadas.', pista:'Buscar por reserva, huésped, habitación o fecha…', columnas:[['id','Reserva'],['huesped','Huésped'],['habitacion','Habitación'],['inicio','Entrada'],['fin','Salida'],['estado','Estado registrado']] },
 servicio_adicional: { titulo:'Servicios', descripcion:'Servicios adicionales registrados en el hotel.', pista:'Buscar por servicio, ID o fecha…', columnas:[['id','ID'],['tipo','Servicio'],['costo','Costo (Q)'],['fecha','Fecha solicitada']] },
 facturacion: { titulo:'Facturación', descripcion:'Consulta los comprobantes y sus formas de pago.', pista:'Buscar por factura, huésped, método o fecha…', columnas:[['id','Factura'],['huesped','Huésped'],['fecha','Fecha'],['monto','Monto (Q)'],['metodo','Método de pago']] },
 servicio_reservacion: { titulo:'Servicios por reserva', descripcion:'Cada servicio solicitado, incluso cuando se repite.', pista:'Buscar por reserva, huésped, servicio o fecha…', columnas:[['id','ID'],['reservacion','Reserva'],['huesped','Huésped'],['servicio','Servicio'],['costo','Costo de catálogo (Q)'],['fecha','Fecha del servicio']] }
};
let seccion='habitaciones', pagina=1, siguiente=false, timer, debounce, controlador, secuencia=0;
const moneda = new Intl.NumberFormat('es-GT',{minimumFractionDigits:2,maximumFractionDigits:2});
$('fecha').textContent=new Intl.DateTimeFormat('es-GT',{dateStyle:'long'}).format(new Date());
function limpiar() {
 $('filas').replaceChildren(); $('tabla-contenedor').hidden=true; $('vacio').hidden=true;
 for(const key of ['habitaciones','disponibles','huespedes','reservaciones']) $('m-'+key).textContent='—';
 $('anterior').disabled=true; $('siguiente').disabled=true;
}
function mostrar(datos) {
 const config=secciones[seccion];
 $('encabezados').replaceChildren(); const tr=document.createElement('tr');
 for(const [,nombre] of config.columnas) { const th=document.createElement('th'); th.scope='col'; th.textContent=nombre; tr.append(th); }
 $('encabezados').append(tr); $('filas').replaceChildren();
 for(const fila of datos.datos) {
  const row=document.createElement('tr');
  for(const [clave] of config.columnas) {
   const td=document.createElement('td'); const valor=fila[clave];
   if(clave==='estado') { const badge=document.createElement('span'); badge.className='badge'+(valor?'':' no'); badge.textContent=seccion==='habitaciones'?(valor?'Disponible':'No disponible'):(valor?'TRUE':'FALSE'); td.append(badge); }
   else td.textContent=valor===null?'—':(['costo','monto'].includes(clave)?moneda.format(Number(valor)):String(valor));
   row.append(td);
  } $('filas').append(row);
 }
 $('tabla-contenedor').hidden=datos.datos.length===0; $('vacio').hidden=datos.datos.length!==0;
 for(const [key,valor] of Object.entries(datos.resumen)) $('m-'+key).textContent=valor;
 siguiente=datos.siguiente;
 $('resultado').textContent=datos.datos.length ? `Mostrando ${(pagina-1)*20+1}–${(pagina-1)*20+datos.datos.length} · Datos de la base` : 'Sin registros para esta consulta';
 $('pagina').textContent=`Página ${pagina}`; $('anterior').disabled=pagina===1; $('siguiente').disabled=!siguiente;
 $('ultima').textContent='Última consulta: '+new Date(datos.comprobado).toLocaleTimeString('es-GT');
}
async function cargar(inicial=false) {
 clearTimeout(timer); if(controlador) controlador.abort(); const numero=++secuencia;
 controlador=new AbortController(); const actual=controlador;
 const limite=setTimeout(()=>actual.abort(),15000);
 if(inicial){ limpiar(); $('aviso').hidden=true; $('cargando').hidden=false; $('resultado').textContent='Consultando…'; $('conexion').textContent='Comprobando conexión'; $('conexion').className='estado esperando'; }
 try {
  const parametros=new URLSearchParams({seccion,q:$('consulta').value,pagina:String(pagina),estado:$('filtro').value});
  const response=await fetch('/api/datos?'+parametros,{signal:actual.signal,cache:'no-store',credentials:'same-origin'});
  if(response.status===401) throw {codigo:'SESION',mensaje:'La sesión no está autorizada. Recarga la página e ingresa con la cuenta del equipo.'};
  let datos; try {datos=await response.json();} catch {throw {codigo:'SERVIDOR',mensaje:'El servidor web no entregó una respuesta válida. Intenta nuevamente.'};}
  if(!response.ok) throw datos;
  if(numero!==secuencia) return;
  mostrar(datos); $('aviso').hidden=true; $('conexion').textContent='Base de datos conectada'; $('conexion').className='estado';
 } catch(error) {
  if(numero!==secuencia) return;
  limpiar(); $('aviso').hidden=false;
  $('aviso-titulo').textContent=error.codigo==='BASE_NO_DISPONIBLE'?'No podemos comunicarnos con la base de datos':'No podemos consultar la información';
  $('aviso-texto').textContent=error.mensaje||'No se pudo contactar al servidor web a tiempo. Comprueba la conexión. Volveremos a intentarlo automáticamente.';
  $('conexion').textContent=error.codigo==='BASE_NO_DISPONIBLE'?'Base de datos no disponible':'Servicio no disponible'; $('conexion').className='estado error';
  $('resultado').textContent='Información no disponible · Reintento automático';
 } finally {
  clearTimeout(limite);
  if(numero===secuencia){ $('cargando').hidden=true; timer=setTimeout(()=>cargar(),5000); }
 }
}
for(const boton of document.querySelectorAll('[data-seccion]')) boton.addEventListener('click',()=>{
 seccion=boton.dataset.seccion; pagina=1; $('consulta').value=''; $('filtro').value='todos';
 for(const b of document.querySelectorAll('[data-seccion]')) {b.classList.toggle('activo',b===boton); if(b===boton)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');}
 const config=secciones[seccion]; $('ruta').textContent=config.titulo; $('titulo-seccion').textContent=config.titulo; $('caption').textContent=config.titulo; $('descripcion').textContent=config.descripcion; $('consulta').placeholder=config.pista; $('filtro-grupo').hidden=seccion!=='habitaciones'; cargar(true);
});
$('busqueda').addEventListener('submit',e=>{e.preventDefault();clearTimeout(debounce);pagina=1;cargar(true);});
$('consulta').addEventListener('input',()=>{clearTimeout(debounce);debounce=setTimeout(()=>{pagina=1;cargar(true);},350);});
$('filtro').addEventListener('change',()=>{pagina=1;cargar(true);});
$('anterior').addEventListener('click',()=>{if(pagina>1){pagina--;cargar(true);}});
$('siguiente').addEventListener('click',()=>{if(siguiente){pagina++;cargar(true);}});
$('actualizar').addEventListener('click',()=>cargar(true)); $('reintentar').addEventListener('click',()=>cargar(true));
window.addEventListener('online',()=>cargar(true));
cargar(true);
